package ejercicio02;

public interface IImpuesto {
	double calculoIva(int iva);
    double calculoIrpf(double sueldo); 
}
