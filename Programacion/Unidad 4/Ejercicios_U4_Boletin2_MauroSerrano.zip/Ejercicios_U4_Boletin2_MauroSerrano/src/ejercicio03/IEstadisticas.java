package ejercicio03;

public interface IEstadisticas {
	double calcularMinimo( );//Devuelve el menor número del array
	double calcularMaximo( );//Devuelve el mayor número en el array
	double calcularSumatorio( );//Devuelve la suma de los elementos del array
}
