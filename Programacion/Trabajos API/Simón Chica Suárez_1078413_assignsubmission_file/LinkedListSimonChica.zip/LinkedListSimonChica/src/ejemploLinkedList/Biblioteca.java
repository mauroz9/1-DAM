package ejemploLinkedList;

import java.util.LinkedList;

public class Biblioteca {

	
	private LinkedList<Libro> libros;

	
	public LinkedList<Libro> getLibros() {
		return libros;
	}


	public void setLibros(LinkedList<Libro> libros) {
		this.libros = libros;
	}

	

	@Override
	public String toString() {
		return "Biblioteca [libros=" + libros + "]";
	}


	public Biblioteca(LinkedList<Libro> libros) {
		super();
		this.libros = libros;
	}

	

	//Para agregar
	public void agregarLibro(Libro li) {
        libros.add(li);
    }
	
	
	//Buscar por ISBN
	public Libro buscarPorISBN(String isbn) {
        for (Libro li : libros) {
            if (li.getIsbn().equals(isbn)) {
                return li;
            }
        }
        return null;
    }
	
	//Modificar la disponibilidad
	public void modificarDisponibilidad(String isbn, boolean disponibilidad) {
	        Libro li = buscarPorISBN(isbn);
	        if (li != null) {
	            li.setDisponible(disponibilidad);
	        }
	    }
	
	
	//Mostrar libros disponibles
	public void mostrarLibrosDisponibles() {
        for (Libro li : libros) {
            if (li.isDisponible()) {
                System.out.println(li);
            }
        }
    }
	
	//Obtener cantidad de libros
	public int obtenerCantidadLibros() {
        return libros.size();
    }
	
	//Eliminar libro por isbn
	public void eliminarLibro(String isbn) {
        for (int i = 0; i < libros.size(); i++) {
            if (libros.get(i).getIsbn().equals(isbn)) {
                libros.remove(i);
                return ;
            }
        }
    }
}
