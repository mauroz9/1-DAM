package ejemploLinkedList;

import java.util.LinkedList;
import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {

		//Se desea desarrollar una app para gestionar una biblioteca digital. Se tendrá una clase Libro con las siguientes características:
		//Título, Autor, ISBN( único para cada libro), Año de publicación, Disponible(indica si el libro está prestado o no).
		//Además, se creará una clase Biblioteca que gestionará una lista de libros mediante una estructura LinkedList. Esta clase debe permitir las siguientes operaciones:
		//Agregar un nuevo libro al final de la lista con los datos ingresados por teclado.
		//Buscar un libro por ISBN y devolver sus datos.
		//Eliminar un libro de la lista dado su ISBN.
		//Modificar los datos de un libro, permitiendo cambiar el estado de disponibilidad.
		//Mostrar solo los libros disponibles.
		//Se creará una clase principal con un menú interactivo para probar todas las funcionalidades, permitiendo repetir acciones hasta que el usuario decida salir. Se pueden agregar algunos libros de prueba al inicio o implementar un método que cargue datos automáticamente.
		
		Scanner scanner = new Scanner(System.in);
		int opcion=0;
		Libro l1 = new Libro("El Quijote", "Cervantes", "1234", 1605, true);
        Libro l2 = new Libro("Cien años de soledad", "García Márquez", "5678", 1967, false);
        Libro l3 = new Libro("1984", "George Orwell", "91011", 1949, true);
        LinkedList<Libro>lista=new LinkedList<>(); 
        Biblioteca biblioteca = new Biblioteca(lista);
		
        biblioteca.agregarLibro(l1);
        biblioteca.agregarLibro(l2);
        biblioteca.agregarLibro(l3);

		
        do {
        	System.out.println("Bienvenido al programa");
            System.out.println("1. Agregar libro");
            System.out.println("2. Buscar por ISBN");
            System.out.println("3. Eliminar libro");
            System.out.println("4. Modificar disponibilidad");
            System.out.println("5. Mostrar libros disponibles");
            System.out.println("6. Salir");
            opcion = scanner.nextInt();
            scanner.nextLine(); 

            switch (opcion) {
                case 1:
                    System.out.print("Título: ");
                    String titulo = scanner.nextLine();
                    System.out.print("Autor: ");
                    String autor = scanner.nextLine();
                    System.out.print("ISBN: ");
                    String isbn = scanner.nextLine();
                    System.out.print("Año de publicación: ");
                    int anio = scanner.nextInt();
                    System.out.print("¿Disponible? (true/false): ");
                    boolean disponible = scanner.nextBoolean();
                    biblioteca.agregarLibro(new Libro(titulo, autor, isbn, anio, disponible));
                    break;
                    
                case 2:
                    System.out.print("Ingrese ISBN: ");
                    System.out.println(biblioteca.buscarPorISBN(scanner.nextLine()));
                    break;
               
                case 3:
                    System.out.print("Ingrese ISBN para eliminar un libro: ");
                    isbn = scanner.nextLine();
                    biblioteca.eliminarLibro(isbn);
                    break;	
                    
                case 4:
                    System.out.print("Ingrese ISBN para cambiar disponibilidad: ");
                    String modIsbn = scanner.nextLine();
                    System.out.print("Disponible (true/false): ");
                    boolean modDisponible = scanner.nextBoolean();
                    biblioteca.modificarDisponibilidad(modIsbn, modDisponible);
                    break;
                    
                case 5:
                    biblioteca.mostrarLibrosDisponibles();
                    break;
                    
                case 6:
                    System.out.println("Saliendo...");
                    break;
                    
                default:
                    System.out.println("Opción inválida.");
            }
        } while (opcion != 0);

        scanner.close();
		
		
	}

}
