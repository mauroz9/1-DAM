package EjemploJava13;

public class ejemploTextBlock {

	public static void main(String[] args) {
		
		// Definición de una cadena múltitarea utilizando Text Blocks
		String mensaje = """
				¡Hola mundo!
				Bienvenido a la demostración de Text Blocks en Java 13.
				Esta caracteristica permite manejar cadenas de texto multitarea
				de forma más sencilla y legible.
				""";
		
		// Imprimir el mensaje en la consola
		System.out.println(mensaje);
	}

}
