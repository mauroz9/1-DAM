package EjemploJava16;

//Definición de un Record en Java 16
//Ahora es una característica oficial del lenguaje.
record Persona(String nombre, int edad) {
 
 // Nueva funcionalidad: Constructores Compactos (Java 16)
 Persona {
     if (edad < 0) {  // Validación antes de asignar el valor
         throw new IllegalArgumentException("La edad no puede ser negativa");
     }
 }

 // Nueva funcionalidad: Métodos adicionales en Records (Java 16)
 public String saludo() {
     return "Hola, soy " + nombre + " y tengo " + edad + " años.";
 }
}

public class RecordsMejorado {
	
 public static void main(String[] args) {
     // Crear instancias de Persona
     Persona p1 = new Persona("Juan", 30);
     Persona p2 = new Persona("Ana", 25);

     // Mostrar datos con el método toString() automático
     System.out.println(p1); // Salida: Persona[nombre=Juan, edad=30]
     System.out.println(p2); // Salida: Persona[nombre=Ana, edad=25]

     // Validación automática (edad negativa genera error)
     // Persona p3 = new Persona("Carlos", -5); //  Esto lanzaría una excepción

     // Llamar al método adicional definido en el Record
     System.out.println(p1.saludo()); // Salida: Hola, soy Juan y tengo 30 años.
 }
}

