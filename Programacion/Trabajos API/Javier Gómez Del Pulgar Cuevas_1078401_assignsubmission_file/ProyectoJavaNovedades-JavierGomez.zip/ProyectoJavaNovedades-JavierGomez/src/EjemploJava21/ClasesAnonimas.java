package EjemploJava21;

// Este programa usa características de Java 21.
// Asegúrate de tener instalado Java SE 21 antes de ejecutarlo.
// Para verificar tu versión, usa: java -version
// Para compilar y ejecutar: 
//     javac Tareas.java
//     java Tareas

import java.util.ArrayList;
import java.util.Scanner;

// Se define una clase principal llamada Tareas
public class ClasesAnonimas {
    // Lista para almacenar las tareas
    private ArrayList<String> tareas = new ArrayList<>();

    // Método main: punto de entrada del programa
    public static void main(String[] args) {
        new ClasesAnonimas().ejecutar(); // Se crea una instancia de la clase y se llama al método ejecutar()
    }

    // Método principal que maneja el flujo del programa
    void ejecutar() {
        Scanner scanner = new Scanner(System.in); // Objeto para leer la entrada del usuario
        
        System.out.println("=== Administrador de Tareas ===");

        // Bucle infinito para mostrar el menú hasta que el usuario elija salir
        while (true) {
            mostrarMenu(); // Muestra las opciones disponibles
            System.out.print("Elige una opción: ");
            String opcion = scanner.nextLine(); // Captura la opción ingresada

            // Estructura de control para ejecutar la opción elegida
            if (opcion.equals("1")) {
                agregarTarea(scanner);
            } else if (opcion.equals("2")) {
                mostrarTareas();
            } else if (opcion.equals("3")) {
                eliminarTarea(scanner);
            } else if (opcion.equals("4")) {
                System.out.println("Saliendo..."); // Mensaje de salida
                return; // Termina el programa
            } else {
                System.out.println("Opción inválida, intenta de nuevo.");
            }
        }
    }

    // Muestra el menú de opciones en la pantalla
    void mostrarMenu() {
        System.out.println("\n1. Agregar Tarea");
        System.out.println("2. Mostrar Tareas");
        System.out.println("3. Eliminar Tarea");
        System.out.println("4. Salir");
    }

    // Método para agregar una nueva tarea
    void agregarTarea(Scanner scanner) {
        System.out.print("Escribe la nueva tarea: ");
        String tarea = scanner.nextLine(); // 📌 Captura el texto ingresado por el usuario
        tareas.add(tarea); //  Agrega la tarea a la lista
        System.out.println("Tarea agregada.");
    }

    // Método para mostrar todas las tareas guardadas
    void mostrarTareas() {
        if (tareas.isEmpty()) { // Si la lista está vacía
            System.out.println("No hay tareas pendientes.");
            return;
        }

        System.out.println("\nLista de Tareas:");
        // 🔹 Se recorre la lista y se muestra cada tarea con su número
        for (int i = 0; i < tareas.size(); i++) {
            System.out.println((i + 1) + ". " + tareas.get(i));
        }
    }

    // Método para eliminar una tarea por su número en la lista
    void eliminarTarea(Scanner scanner) {
        mostrarTareas(); // Primero muestra las tareas disponibles
        if (tareas.isEmpty()) { // Si no hay tareas, no tiene sentido continuar
            return;
        }

        System.out.print("Ingrese el número de la tarea a eliminar: ");
        String entrada = scanner.nextLine(); // 📌 Captura el número ingresado como texto
        int index = Integer.parseInt(entrada) - 1; // 📌 Convierte el texto a número y ajusta el índice

        // Verifica que el número ingresado esté dentro de la lista
        if (index >= 0 && index < tareas.size()) {
            tareas.remove(index); // Elimina la tarea seleccionada
            System.out.println("Tarea eliminada.");
        } else {
            System.out.println("Número inválido."); // Mensaje si el número no es correcto
        }
    }
}
