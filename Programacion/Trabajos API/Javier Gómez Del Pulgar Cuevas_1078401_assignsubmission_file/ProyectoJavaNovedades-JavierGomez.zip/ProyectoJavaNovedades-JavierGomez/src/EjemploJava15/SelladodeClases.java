package EjemploJava15;

// 1️⃣ Definición de una clase sellada que solo permite herencia a Circulo y Rectangulo
sealed abstract  class Figura permits Circulo, Rectangulo {
    // Método abstracto que debe ser implementado por las subclases
    abstract double calcularArea();
}

// 2️⃣ Clase Circulo que hereda de Figura (final → no puede ser extendida por más clases)
final class Circulo extends Figura {
    double radio;

    // Constructor para inicializar el radio del círculo
    public Circulo(double radio) {
        this.radio = radio;
    }

    // Implementación del método calcularArea() para Circulo
    @Override
    double calcularArea() {
        return Math.PI * radio * radio;
    }
}

// 3️⃣ Clase Rectangulo que hereda de Figura (non-sealed → permite herencia libre)
non-sealed class Rectangulo extends Figura {
    double ancho, alto;

    // Constructor para inicializar las dimensiones del rectángulo
    public Rectangulo(double ancho, double alto) {
        this.ancho = ancho;
        this.alto = alto;
    }

    // Implementación del método calcularArea() para Rectangulo
    @Override
    double calcularArea() {
        return ancho * alto;
    }
}

// 4️⃣ Clase Cuadrado que hereda de Rectangulo, permitida porque Rectangulo es non-sealed
class Cuadrado extends Rectangulo {
    public Cuadrado(double lado) {
        super(lado, lado); // Un cuadrado es un rectángulo con lados iguales
    }
}

public class SelladodeClases {
	
    public static void main(String[] args) {
    	
        // 5️⃣ Creación de instancias de las clases selladas y no selladas
        Figura circulo = new Circulo(5); // Creando un Círculo de radio 5
        Figura rectangulo = new Rectangulo(4, 6); // Creando un Rectángulo de 4x6
        Figura cuadrado = new Cuadrado(3); // Creando un Cuadrado de 3x3

        // 6️⃣ Llamando al método calcularArea() para cada figura
        System.out.println("Área del círculo: " + circulo.calcularArea()); // π * r^2
        System.out.println("Área del rectángulo: " + rectangulo.calcularArea()); // ancho * alto
        System.out.println("Área del cuadrado: " + cuadrado.calcularArea()); // lado * lado

        // 7️⃣ Uso de instanceof mejorado en Java 15 para evitar casting manual
        if (circulo instanceof Circulo c) { 
            // Si 'circulo' es una instancia de Circulo, se crea la variable 'c'
            System.out.println("El radio del círculo es: " + c.radio);
        }

        // 8️⃣ Uso de getClass() para obtener el tipo de objeto en tiempo de ejecución
        System.out.println("El objeto 'circulo' es de tipo: " + circulo.getClass().getSimpleName());
        System.out.println("El objeto 'rectangulo' es de tipo: " + rectangulo.getClass().getSimpleName());
        System.out.println("El objeto 'cuadrado' es de tipo: " + cuadrado.getClass().getSimpleName());
    }
}
