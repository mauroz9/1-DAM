package EjemploJava19;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HilosVirtuales {
	
    public static void main(String[] args) {
    	
    	// 1️⃣ Creamos un ExecutorService que usa hilos virtuales si no se declara no se puede hacer los hilos virtuales
        ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor();

        // 2️⃣ Ejecutamos 5 tareas en hilos virtuales
        for (int i = 1; i <= 5; i++) {
            final int tareaID = i;
            executor.execute(new Runnable() {
                @Override
                public void run() {
                	
                	// La expresión Thread.currentThread() es un método que devuelve una referencia al hilo que está ejecutando 
                	//el código en ese momento. Es un método estático de la clase Thread en Java y se utiliza para obtener el hilo actual 
                	//(el hilo que está ejecutando en ese momento el bloque de código en el que se llama a este método).
                	
                    System.out.println("Tarea " + tareaID + " ejecutada en el hilo: " + Thread.currentThread());
                }
            });
        }

        // 3️⃣ Cerramos el ejecutor cuando ya no lo necesitamos
        executor.shutdown();
    }
}

