package EjemploJava20;

import java.util.Vector;

public class EjemploVector {
	
    public static void main(String[] args) {
        // Crear un Vector de tipo String
        Vector<String> nombres = new Vector<>();

        // Agregar elementos al Vector
        nombres.add("Juan");
        nombres.add("María");
        nombres.add("Carlos");
        nombres.add("Ana");
        nombres.add("Juan"); // Se permite agregar duplicados

        // Mostrar los elementos del Vector
        System.out.println("Elementos en el Vector: " + nombres);

        // Obtener un elemento por índice
        System.out.println("Elemento en la posición 2: " + nombres.get(2));

        // Verificar si el Vector contiene un elemento
        if (nombres.contains("María")) {
            System.out.println("El nombre 'María' está en el Vector.");
        }

        // Eliminar un elemento
        nombres.remove("Carlos");
        System.out.println("Después de eliminar 'Carlos': " + nombres);

        // Obtener el tamaño del Vector
        System.out.println("Tamaño del Vector: " + nombres.size());

        // Recorrer el Vector con un bucle for
        System.out.println("Recorriendo el Vector con un bucle for:");
        for (String nombre : nombres) {
            System.out.println(nombre);
        }
    }
}

//Se crea un Vector de tipo String para almacenar nombres.
//Se agregan elementos al Vector, incluyendo duplicados.
//Se accede a un elemento por su índice.
//Se verifica si un elemento está presente en el Vector.
//Se elimina un elemento específico.
//Se obtiene el tamaño actual del Vector.
//Se recorre el Vector usando un bucle for-each.
//Aunque Vector es seguro para múltiples hilos debido a su sincronización, en la mayoría de los casos se recomienda usar ArrayList junto con Collections.synchronizedList() 
//si necesitas seguridad en un entorno concurrente, ya que Vector tiene un rendimiento más bajo

//Collections.synchronizedList() es un método de la clase Collections en Java que devuelve una versión sincronizada de una lista dada. 
//Se usa cuando queremos asegurar el acceso seguro a una List en entornos con múltiples hilos, sin necesidad de utilizar un Vector
