package EjemploJava14;

//Definimos un `record` llamado Persona
//Automáticamente Java genera el constructor, getters, equals(), hashCode() y toString().
record Persona(String nombre, int edad) {}

public class Principal {
	
 public static void main(String[] args) {
     // Crear instancias de Persona
     Persona p1 = new Persona("Juan", 30);
     Persona p2 = new Persona("Ana", 25);

     // Imprimir los datos (Java usa el método toString() generado automáticamente)
     System.out.println(p1); // Salida: Persona[nombre=Juan, edad=30]
     System.out.println(p2); // Salida: Persona[nombre=Ana, edad=25]

     // Acceder a los valores con métodos generados automáticamente
     System.out.println("Nombre: " + p1.nombre()); // Obtiene el nombre de p1
     System.out.println("Edad: " + p1.edad());     // Obtiene la edad de p1

     // Comparación con equals() generado automáticamente
     Persona p3 = new Persona("Juan", 30);
     System.out.println(p1.equals(p3)); // true (mismos valores)

     // hashCode() también es generado automáticamente
     System.out.println("HashCode p1: " + p1.hashCode());
     System.out.println("HashCode p3: " + p3.hashCode()); // Mismo hash porque tienen los mismos valores
 }
}
