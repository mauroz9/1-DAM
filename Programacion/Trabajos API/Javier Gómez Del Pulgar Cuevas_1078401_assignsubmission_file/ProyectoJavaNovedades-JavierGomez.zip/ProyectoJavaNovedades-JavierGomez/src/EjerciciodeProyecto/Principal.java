package EjerciciodeProyecto;

/*
 * Sistema de Ventas de Videojuegos
 * 
 * Este programa gestiona una tienda de venta de videojuegos utilizando características modernas de Java.
 * Se implementan descuentos, inventario.
 * 
 * Características usadas:
 * - Java 13: Text Blocks para mejorar la legibilidad de cadenas largas.
 * - Java 14/16: Records para representar videojuegos.
 * - Java 15: Clases selladas para controlar descuentos.
 * - Java 19: Hilos virtuales para aplicar descuentos.
 * - Java 20: API de Vectores para gestionar stock.
 * - Java 21: Clase Principal sin nombre para simplificar ejecución.
 * 
 * --- Enunciado del Ejercicio ---
 * 
 * Crear un `record` llamado `Videojuego` con los atributos `nombre` y `precio`.
 * Implementar una jerarquía de clases selladas `Descuento` con:
 *    - `DescuentoFijo`: Aplica un descuento fijo.
 *    - `DescuentoPorcentual`: Aplica un descuento en porcentaje.
 * Usar Hilos virtuales para aplicar descuentos según el precio:
 *    - Si el precio es > 50€, aplicar 10% de descuento.
 *    - Si el precio es <= 50€, aplicar 5€ de descuento.
 * Crear una clase `Venta` que registre ventas y acumule el total.
 * Implementar una clase `Inventario` con un `Vector` para gestionar videojuegos.
 * Implementar un menú en la clase `Principal` que permita:
 *    - Agregar videojuegos al inventario.
 *    - Mostrar inventario.
 *    - Registrar una venta.
 *    - Mostrar el total de ventas.
 *    - Salir del programa.
 * Usar Text Blocks (Java 13) para mejorar la legibilidad del menú.
 */


import java.util.Scanner;

//Clase principal con el menú
public class Principal {
	
 public static void main(String[] args) {
	 
     Scanner scanner = new Scanner(System.in);
     Venta venta = new Venta();
     Inventario inventario = new Inventario();
     
     while (true) {
         String menu = """
             
             ====== MENÚ DE OPCIONES ======
             1. Agregar videojuego al inventario
             2. Mostrar inventario
             3. Registrar una venta
             4. Mostrar total de ventas
             5. Salir
             Seleccione una opción: 
             """;
         
         System.out.print(menu);
         
         int opcion = scanner.nextInt();
         scanner.nextLine(); // Consumir el salto de línea
         
         if (opcion == 1) {
             System.out.print("Ingrese el nombre del videojuego: ");
             String nombre = scanner.nextLine();
             System.out.print("Ingrese el precio del videojuego: ");
             double precio = scanner.nextDouble();
             Videojuego v = new Videojuego(nombre, precio);
             inventario.agregarJuego(v);
             System.out.println("Videojuego agregado al inventario.");
         } else if (opcion == 2) {
             inventario.mostrarStock();
         } else if (opcion == 3) {
             System.out.print("Ingrese el nombre del videojuego a vender: ");
             String nombre = scanner.nextLine();
             Videojuego v = inventario.obtenerPorNombre(nombre);
             if (v != null) {
                 venta.registrarVenta(v);
                 System.out.println("Venta registrada para: " + nombre);
             } else {
                 System.out.println("El videojuego no está en inventario.");
             }
         } else if (opcion == 4) {
             System.out.println("Total ventas: " + venta.getTotalVentas());
         } else if (opcion == 5) {
             System.out.println("Saliendo...");
             break;
         } else {
             System.out.println("Opción no válida, intente de nuevo.");
         }
     }
     scanner.close();
 }
}