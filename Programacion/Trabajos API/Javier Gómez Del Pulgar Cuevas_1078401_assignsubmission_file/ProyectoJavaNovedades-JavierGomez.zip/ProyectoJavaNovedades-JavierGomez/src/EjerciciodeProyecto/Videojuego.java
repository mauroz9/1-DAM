package EjerciciodeProyecto;

//Clase para representar un Videojuego
record Videojuego(String nombre, double precio) {}

//Interfaz sellada para descuentos
sealed interface Descuento permits DescuentoFijo, DescuentoPorcentual {}

//Implementación de descuento fijo
final class DescuentoFijo implements Descuento {
	private final double cantidad;
	public DescuentoFijo(double cantidad) {
		this.cantidad = cantidad;
 }
	public double aplicar(double precio) {
     return precio - cantidad;
   }
}

//Implementación de descuento porcentual

final class DescuentoPorcentual implements Descuento {
	
	private final double porcentaje;
	public DescuentoPorcentual(double porcentaje) {
     this.porcentaje = porcentaje;
 }
	public double aplicar(double precio) {
		return precio * (1 - porcentaje / 100);
     }
}