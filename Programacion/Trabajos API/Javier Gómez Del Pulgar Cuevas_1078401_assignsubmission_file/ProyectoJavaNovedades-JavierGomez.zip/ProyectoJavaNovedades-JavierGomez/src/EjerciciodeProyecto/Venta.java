package EjerciciodeProyecto;

import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

// Clase para gestionar las ventas con hilos virtuales (Java 19)
class Venta {
	
    private double totalVentas = 0; // Variable para almacenar el total de ventas

    public double registrarVenta(Videojuego v) {
        // Creamos un ejecutor de tareas con hilos virtuales (Java 19)
        ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor();

        // Creamos una variable para almacenar el resultado de la venta
        final double[] precioFinal = new double[1];

        // Ejecutamos la venta en un hilo virtual utilizando una clase anónima
        executor.execute(new Runnable() {
            @Override
            public void run() {
                // Determinar qué tipo de descuento aplicar
                Descuento descuento;
                if (v.precio() > 50) {
                    descuento = new DescuentoPorcentual(10); // Descuento del 10%
                } else {
                    descuento = new DescuentoFijo(5); // Descuento fijo de 5€
                }

                // Aplicamos el descuento con casting tradicional
                if (descuento instanceof DescuentoFijo) {
                    DescuentoFijo df = (DescuentoFijo) descuento;
                    precioFinal[0] = df.aplicar(v.precio());
                } else {
                    DescuentoPorcentual dp = (DescuentoPorcentual) descuento;
                    precioFinal[0] = dp.aplicar(v.precio());
                }

                // Sincronizamos el acceso a totalVentas para evitar problemas de concurrencia
                synchronized (Venta.this) {
                    totalVentas += precioFinal[0];
                }
            }
        });

        // Cerramos el ejecutor cuando ya no se necesiten más tareas
        executor.shutdown();

        // Devolvemos el precio final para que el main lo imprima
        return precioFinal[0];
    }

    // Método para obtener el total de ventas acumuladas
    public double getTotalVentas() {
        return totalVentas;
    }
}


