package EjerciciodeProyecto;

import java.util.Vector;

// el vector es lo mismo que el ArrayList es decir tiene los mismos métodos del ArrayList
class Inventario {
	
    private final Vector<Videojuego> stock = new Vector<>();
    
    public void agregarJuego(Videojuego v) {
        stock.add(v);
    }
    
    public Videojuego obtenerPorNombre(String nombre) {
        for (int i = 0; i < stock.size(); i++) {
            Videojuego v = stock.get(i);
            if (v.nombre().equalsIgnoreCase(nombre)) {
                return v;
            }
        }
        return null;
    }
    
    public void mostrarStock() {
        for (int i = 0; i < stock.size(); i++) {
            Videojuego v = stock.get(i);
            System.out.println(v.nombre() + " - Precio: " + v.precio());
        }
    }
}

