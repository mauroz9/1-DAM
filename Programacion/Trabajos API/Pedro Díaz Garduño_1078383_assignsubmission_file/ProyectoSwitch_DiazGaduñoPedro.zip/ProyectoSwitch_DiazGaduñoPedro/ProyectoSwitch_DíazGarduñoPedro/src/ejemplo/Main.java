package ejemplo;

import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Nos encontramos con un Concesionaio de coches. Nuestro programa va a tener una clase Coche y una clase Concesionario con una lista de coches
//		El usuario debe realizar las operaciones CRUD basicas y usar las sentencias switch, es obligatorio usar todas las expresiones switch vistas en el documento

		Scanner sc = new Scanner(System.in);
		int anio, op ,op2, op3, tipo;
		double nuevoPrecio, precio;
		System.out.println("Bienvenido al concesaionario");
		List <Coche> cocheList = new ArrayList<Coche>();
		Concesionario c = new Concesionario(cocheList);
		String marca, matricula, modelo, servicio,precio2, tipoLavado, tipoRevision;
        c.addCoche(new Coche("1234FDG", "Corolla", "Toyota", 2022, 25000.00));
        c.addCoche(new Coche("5678JHY", "Focus", "Ford", 2023, 27500.50));
        c.addCoche(new Coche("9012KLM", "X5", "BMW", 2021, 52000.75));
        c.addCoche(new Coche("3456JKL", "Clio", "Renault", 2020, 18500.00));
        c.addCoche(new Coche("7890MNC", "Model 3", "Tesla", 2023, 45000.00));
		
		
		do {
			 	System.out.println("\n=== CONCESIONARIO ===");
	            System.out.println("1. Gestión de coches");
	            System.out.println("2. Servicios adicionales");
	            System.out.println("0. Salir");
	            System.out.println("Selecciona una opción: ");
	            op = Integer.parseInt(sc.nextLine());
	            
	            switch (op) {
				case 1:
					do {
						System.out.println("\n=== GESTIÓN DE COCHES ===");
			            System.out.println("1. Agregar coche");
			            System.out.println("2. Listar coches");
			            System.out.println("3. Actualizar precio");
			            System.out.println("4. Eliminar coche");
			            System.out.println("0. Volver");
			            System.out.println("Selecciona una opción: ");
			            op2= Integer.parseInt(sc.nextLine());
			            
			            switch (op2) {
						case 1:
								System.out.println("Indica la matricula del coche");
								matricula=sc.nextLine();
								System.out.print("Indica la marca");
			                    marca = sc.nextLine();
			                    System.out.print("Indica el modelo");
			                    modelo = sc.nextLine();
			                    System.out.print("Indica el año de fabricación");
			                    anio = Integer.parseInt(sc.nextLine());
			                    System.out.print("Indica su precio de venta");
			                    precio = Double.parseDouble(sc.nextLine());
			                    c.addCoche(new Coche(matricula, marca, modelo, anio, precio));
			                    System.out.println("\nCoche agregado correctamente");
							break;
						case 2:
								c.listarCoches();
								break;
						case 3:
							
								System.out.println("Indica la matricula del coche que quieres"
										+ "cambiar el precio ");
								matricula= sc.nextLine();
								System.out.println("Indica el nuevo precio del coche");
								nuevoPrecio= Double.parseDouble(sc.nextLine());
								
								if (c.actualizarPrecio(matricula, nuevoPrecio)) {
									System.out.println("Precio actualizado");
								}else {
									System.out.println("El coche no se ha encontrado o no se ha cambiado "
											+ "el precio");
								}
							
							break;
						case 4:
							System.out.println("Indica la matricula del coche que quieres"
									+ "eliminar");
							matricula= sc.nextLine();
							
								if (c.deleteCoche(matricula)) {
									System.out.println("Coche eliminado corerrectamente");
								}else {
									System.out.println("No se ha podido eliminar");
								}
							
							break;
						case 0:
							System.out.println("Saliendo");
							break;
						default:
							System.out.println("Opción no valida");
							break;
						}

			            
					} while (op2!=0);
					break;

					
				case 2: 
					do {
						 	System.out.println("\n=== SERVICIOS ADICIONALES ===");
				            System.out.println("1. Clasificar tipo de coche");
				            System.out.println("2. Calcular coste de servicio");
				            System.out.println("0. Volver");
				            System.out.print("Selección: ");
				            op3 = Integer.parseInt(sc.nextLine());
				            
				            switch (op3) {
							case 1:
								System.out.println("Indica una opción para ver información");
								System.out.println( "\nTipo (1-Compacto, 2-SUV, 3-Deportivo): ");
								tipo=Integer.parseInt(sc.nextLine());
								 switch (tipo) {
			                        case 1: 
			                        	System.out.println("Compacto: Ideal para la ciudad, ofreciendo eficiencia de combustible "
			                        		+ "y maniobrabilidad en espacios reducidos.");;
			                        	break;
			                        case 2: 
			                        	System.out.println("SUV: Perfecto para familias o aventuras al aire libre, "
			                        		+ "con mayor espacio y capacidad para terrenos difíciles.");; 
			                        
			                        	break;
			                        case 3:  
			                        	System.out.println("Deportivo: Diseñado para velocidad y rendimiento, "
			                        			+ "enfocado en una experiencia de conducción dinámica y emocionante.");
			                        	break;
			                        default:
			                        	System.out.println("Opción no valida");
			                        	break;
			                        	
			                    }
								break;
								
							case 2:
								  	System.out.print("\nServicio (Lavado/Mantenimiento/Revision): ");
				                     servicio = sc.nextLine();
				                     precio2 = switch (servicio.toUpperCase()) {
				                     case "LAVADO" -> {
				                         tipoLavado = "Básico";
				                         yield switch (tipoLavado) {
				                             case "Básico" -> "25.00€";
				                             case "Premium" -> "40.00€";
				                             default -> "20.00€";
				                         };
				                     }
				                     case "MANTENIMIENTO" -> {
				                         System.out.println("Incluye revisión completa");
				                         yield "150.00€";
				                     }
				                     case "REVISION" -> {
				                         tipoRevision = "Estándar";
				                         if (tipoRevision.equalsIgnoreCase(tipoRevision)) {
											yield "75.00€";
											
										}else {
											yield "100.00€";
										}
				                     }
				                    
				                     default -> {
				                         System.out.println("Servicio no reconocido");
				                         yield "Consultar precio";
				                     }
				                     };
				                     
				                    System.out.println("Coste: " + precio2);
				                     
				                    break;
				            
							case 0:
								System.out.println("Saliendo");
							default:
								System.out.println("NO valido");
								break;
							}
				            
				            
				            
					} while (op3!=0);
					
				default:
					
					break;
				}
		} while (op != 0);
		System.out.println("Garcias por venir");
		
		
	
	
	}
	

}
