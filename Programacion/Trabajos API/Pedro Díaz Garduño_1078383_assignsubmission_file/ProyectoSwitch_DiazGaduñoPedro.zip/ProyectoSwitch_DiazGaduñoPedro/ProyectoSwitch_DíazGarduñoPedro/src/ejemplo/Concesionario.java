package ejemplo;

import java.util.List;

public class Concesionario {

	private List <Coche> listCoches;

	public List<Coche> getListCoches() {
		return listCoches;
	}

	public void setListCoches(List<Coche> listCoches) {
		this.listCoches = listCoches;
	}

	public Concesionario(List<Coche> listCoches) {
		super();
		this.listCoches = listCoches;
	}

	@Override
	public String toString() {
		return "Concesionario [listCoches=" + listCoches + "]";
	}
	
	public void addCoche(Coche c) {
		listCoches.add(c);
	}
	
	public Coche findByMatricula (String matricula) {
		for (Coche coche : listCoches) {
			if (coche.getMatricula().equalsIgnoreCase(matricula)) {
				return coche;
			}
		}
		return null;
	}
	
	public boolean actualizarPrecio (String matricula, double nuevoPrecio) {
		Coche c = findByMatricula(matricula);
		boolean actualizado;
		if (c != null) {
			c.setPrecio(nuevoPrecio);
			actualizado=true;
		}else {
			actualizado=false;
		}
		return actualizado;
	}

	public boolean deleteCoche (String matricula) {
		Coche  c = findByMatricula(matricula);
		
		return listCoches.remove(c);
	}
	
	public void listarCoches () {
		if (listCoches.isEmpty()) {
            System.out.println("\nNo hay coches registrados");
            return;
        }
        
        
        for (Coche c : listCoches) {
            System.out.println(c);
        }
        
    }

	
}
	
	
	
	
	
	


