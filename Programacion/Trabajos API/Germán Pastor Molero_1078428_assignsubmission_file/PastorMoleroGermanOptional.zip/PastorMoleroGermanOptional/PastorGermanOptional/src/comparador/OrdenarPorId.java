package comparador;

import java.util.Comparator;

import model.Reserva;

public class OrdenarPorId implements Comparator<Reserva>{

	@Override
	public int compare(Reserva r1, Reserva r2) {
		// TODO Auto-generated method stub
		return Integer.compare(r1.getId(), r2.getId());
	}

}
