package model;

public class Reserva implements Comparable<Reserva>{
	
    private int id;
    private String cliente;
    private String fecha;
    
	public Reserva(int id, String cliente, String fecha) {
		super();
		this.id = id;
		this.cliente = cliente;
		this.fecha = fecha;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCliente() {
		return cliente;
	}
	public void setCliente(String cliente) {
		this.cliente = cliente;
	}
	public String getFecha() {
		return fecha;
	}
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	@Override
	public String toString() {
		return "Reserva [id=" + id + ", cliente=" + cliente + ", fecha=" + fecha + "]";
	}

	@Override
	public int compareTo(Reserva r) {
		return r.getCliente().compareTo(cliente);
	}
    

}
