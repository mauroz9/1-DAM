package crud;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import comparador.OrdenarPorId;
import model.Reserva;

public class CrudReserva {

	private List<Reserva> reservas = new ArrayList<>();

	public CrudReserva(List<Reserva> reservas) {
		super();
	}

	public List<Reserva> getReservas() {
		return reservas;
	}

	public void setReservas(List<Reserva> reservas) {
		this.reservas = reservas;
	}

	@Override
	public String toString() {
		return "CrudReserva [reservas=" + reservas + "]";
	}

	public void crearReserva(Reserva r) {
		reservas.add(r);
	}

	public Optional<Reserva> buscarReservaPorId(int id) {
	    // Recorremos la lista de reservas
	    for (Reserva r : reservas) {
	        // Si encontramos una reserva con el id que buscamos
	        if (r.getId() == id) {
	            // Devolvemos la reserva envuelta en un Optional
	            return Optional.of(r);
	        }
	    }
	    // Si no encontramos ninguna reserva con el id, devolvemos un Optional vacío
	    return Optional.empty();
	}

	public boolean modificarNombreReserva(int id, String nuevoNombre) {
		Optional<Reserva> reservaOpt = buscarReservaPorId(id);
		Reserva r = null;

		if (reservaOpt.isPresent()) {
			r = reservaOpt.get();
			r.setCliente(nuevoNombre);
			return true; // Indica que la modificación fue exitosa
		}
		return false; // Indica que la reserva no fue encontrada
	}

	public boolean eliminarReserva(int id) {
		// Buscar la reserva por ID usando Optional
		Optional<Reserva> reservaOpt = buscarReservaPorId(id);
		Reserva r = null;
		// Verificar si la reserva existe
		if (reservaOpt.isPresent()) {
			r = reservaOpt.get(); // Obtener la reserva
			reservas.remove(r); // Eliminar la reserva de la lista
			return true; // Indica que la eliminación fue exitosa
		}
		return false; // Indica que la reserva no fue encontrada
	}

	public void listarReservasConOptionalIfPresentOrElse() {
		// Creamos un Optional con la lista de reservas
		Optional<List<Reserva>> reservasOpt = Optional.ofNullable(reservas);
		List<Reserva> reservasList = null;
		// Usamos ifPresentOrElse para verificar si la lista de reservas no está vacía
		if (reservasOpt.isPresent()) {
			reservasList = reservasOpt.get();

			// Verificar si la lista de reservas está vacía
			if (reservasList.isEmpty()) {
				System.out.println("No hay reservas registradas.");
			} else {
				// Imprimir las reservas si no está vacía
				for (Reserva reserva : reservasList) {
					System.out.println(reserva);
				}
			}
		}
	}

	public Optional<Reserva> obtenerPrimeraReserva() {
		// Verificamos si la lista de reservas está vacía
		if (reservas.isEmpty()) {
			return Optional.empty(); // Si no hay reservas, devolvemos un Optional vacío
		} else {
			return Optional.of(reservas.get(0)); // Si hay reservas, devolvemos la primera envuelta en Optional
		}
	}
	
	public int contarReservas() {
	    int contador=0;
		for(Reserva r:reservas) {
	    	contador++;
	    }
		return contador;
	}
	
	public List ordenarPorNombre() {
		List<Reserva> newList=new ArrayList<Reserva>(reservas);
		Collections.sort(newList);
		return newList;
	}
	
	public List ordenarPoId() {
		List<Reserva> newList=new ArrayList<Reserva>(reservas);
		Collections.sort(newList, new OrdenarPorId());
		return newList;
	}
}