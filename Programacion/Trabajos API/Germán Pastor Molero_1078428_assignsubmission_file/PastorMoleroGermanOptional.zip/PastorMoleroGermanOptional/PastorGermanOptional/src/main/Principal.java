package main;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import crud.CrudReserva;
import model.Reserva;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * Desarrollar una aplicación en Java para gestionar un sistema de reservas,
		 * donde se utilicen Optional para manejar de forma segura los posibles valores
		 * nulos al realizar operaciones sobre la lista de reservas.
		 * 
		 * Requisitos:
		 * 
		 * Crear una reserva: Agregar una nueva reserva a la lista.
		 * 
		 * Buscar una reserva por ID: Utilizar Optional<Reserva> para devolver la
		 * reserva si se encuentra, o un Optional.empty() si no se encuentra.
		 * 
		 * Modificar el nombre de un cliente: Modificar el nombre del cliente en una
		 * reserva usando su ID. Si la reserva existe, se debe actualizar correctamente.
		 * 
		 * Eliminar una reserva por ID: Usar Optional<Reserva> para verificar si la
		 * reserva existe y luego eliminarla de la lista.
		 * 
		 * Listar todas las reservas: Utilizar Optional<List<Reserva>> para comprobar si
		 * la lista está vacía y mostrar un mensaje adecuado si no hay reservas.
		 * 
		 * Obtener la primera reserva: Usar Optional<Reserva> para devolver la primera
		 * reserva de la lista si existe, o Optional.empty() si la lista está vacía.
		 * 
		 * Contar el número total de reservas: Devolver el número total de reservas 
		 * 
		 * Ordenar las reservas alfabéticamente por nombre del cliente: Devolver la
		 * lista ordenada alfabéticamente por el nombre del cliente.
		 * 
		 * Ordenar las reservas por ID: Ordenar las reservas por ID utilizando un
		 * Comparator y devolver la lista ordenada.
		 */

		Scanner sc = new Scanner(System.in);
		List<Reserva> list = new ArrayList<Reserva>();
		CrudReserva cs = new CrudReserva(list);
		int opcion, id = 0;
		String nombre, fecha;
		boolean encontrado = false;
		Reserva r = new Reserva(1, "Pedro", "12/12/2025");
		Reserva r1 = new Reserva(2, "Andrés", "12/09/2025");
		Reserva r2 = new Reserva(3, "Isco", "12/10/2025");
		Reserva r3 = new Reserva(4, "Ángel", "12/11/2025");
		cs.crearReserva(r);
		cs.crearReserva(r3);
		cs.crearReserva(r2);
		cs.crearReserva(r1);

		do {
			System.out.println("\n--- Menú de Reservas ---");
			System.out.println("1. Crear reserva");
			System.out.println("2. Buscar Reserva");
			System.out.println("3. Modificar el nombre de la reserva");
			System.out.println("4. Eliminar reserva");
			System.out.println("5. Listar reservas");
			System.out.println("6. Ver la primera reserva");
			System.out.println("7. Lista ordenada por nombre");
			System.out.println("8. Lista ordenada por Id");
			System.out.println("9. Número de Reservas");
			System.out.println("10. Salir");
			System.out.print("Seleccione una opción: ");
			opcion = sc.nextInt();
			sc.nextLine();

			switch (opcion) {
				case 1:
					System.out.println("Dime la id del cliente");
					id = Integer.parseInt(sc.nextLine());
					System.out.print("Ingrese nombre del cliente: ");
					nombre = sc.nextLine();
					System.out.print("Ingrese fecha de reserva: ");
					fecha = sc.nextLine();
					r = new Reserva(id, nombre, fecha);
					cs.crearReserva(r);
					System.out.println("Reserva creada exitosamente.");
					break;
				case 2:
					System.out.print("Ingrese ID de la reserva: ");
					id = Integer.parseInt(sc.nextLine());
					cs.buscarReservaPorId(id);
					if (cs.buscarReservaPorId(id).isPresent()) {
						System.out.println(cs.buscarReservaPorId(id));
					} else {
						System.out.println("No se ha encontrado la reserva");
					}
					break;
				case 3:
					System.out.println("Dime la id de la reserva al que le quieres modificar el nombre");
					id = Integer.parseInt(sc.nextLine());
					System.out.println("Dime el nombre que le quieres poner");
					nombre = sc.nextLine();
					encontrado = cs.modificarNombreReserva(id, nombre);
					if (encontrado) {
						System.out.println("Nombre de la reserva actualizado a: " + nombre);
					} else {
						System.out.println("No se ha encontrado la reserva");
					}
					break;
				case 4:
					System.out.println("Dime la id del cliente que quieres eliminar");
					id = Integer.parseInt(sc.nextLine());
					encontrado = cs.eliminarReserva(id);
					if (encontrado) {
						System.out.println("Reserva con ID " + id + " eliminada correctamente.");
					} else {
						System.out.println("No se ha encontrado la reserva");
					}
					break;
				case 5:
					cs.listarReservasConOptionalIfPresentOrElse();
					break;
				case 6:
					cs.obtenerPrimeraReserva();
					if (cs.obtenerPrimeraReserva().isPresent()) {
						// Extraemos la reserva y la mostramos
						r = cs.obtenerPrimeraReserva().get();
						System.out.println("Primera reserva: " + r);
					} else {
						// Si el Optional está vacío, mostramos un mensaje indicando que no hay reservas
						System.out.println("No hay reservas registradas.");
					}
					break;
				case 7:
					System.out.println(cs.ordenarPorNombre());
					break;
				case 8:
					System.out.println(cs.ordenarPoId());
					break;
				case 9:
					cs.contarReservas();
					if (cs.contarReservas() >= 1) {
						System.out.println("Hay " + cs.contarReservas() + " reservas añadidas");
					} else {
						System.out.println("No hay reservas añadidas");
					}
					break;
				case 10:
					System.out.println("Saliendo.....");
					System.out.println("Gracias por utilizar mi programa");
					break;
				default:
					System.out.println("Elige una opción valida");
					break;
			}
		} while (opcion != 6);
		sc.close();
	}

}
